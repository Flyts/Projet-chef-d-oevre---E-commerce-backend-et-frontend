<?php

	return 
	[

		'titre'       => 'Modifier Mon Compte',
		'changer'     => 'Changer la photo',
		'supprimer'   => 'Supprimer la photo',

		'info_General'     => 'Informations Générale',
		'nom'              => 'Nom',
		'placeholder_Nom'    => 'Tapez votre nom',
		'prenom'           => 'Prénom',
		'placeholder_Prenom' => 'Tapez votre prénom',

		'info_Compte'       => 'Informations Sur Le Compte',
		'email'             => 'Adresse mail',
		'tel'               => 'Numéro de téléphone',
		'placeholder_email' => 'Tapez votre adresse mail',
		'placeholder_tel'   => 'Tapez votre numéro de téléphone',
		'identifiant'       => 'Identifiant',
		'placeholder_id'    => 'Tapez votre identifiant',

		'change_passe'     => 'Changer le mot de passe',
		'pass_actuel'      => 'Mot de passe actuel',
		'pass_new'         => 'Nouveau mot de passe',
		'placeholder_pass' => '8 Caractères minimum',
		'confirm_pass'     => 'Confirmer le mot de passe',

		'btn_enregistrer'  => 'Enregistrer',

		'btn_file'         => 'Choisissez une photo',
		'file_span_text'   => 'Aucun fichier Choisi',

	]

?>