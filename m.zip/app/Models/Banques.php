<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Banques extends Model
{
    protected $fillable = [
        'user_id',
        'solde',
        'depense',
    ];

    public $timestamps = false;
}
