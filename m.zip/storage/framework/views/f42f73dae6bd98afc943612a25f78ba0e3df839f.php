<div id="Ajax_Loader">
	<svg>
		<circle cx="70" cy="70" r="70">
		</circle>	
	</svg>
	
	<div class="image">
	</div>
</div><?php /**PATH /home/samy/Projets/Samy/E-commerce/resources/views/layouts/partials/_AjaxLoader.blade.php ENDPATH**/ ?>