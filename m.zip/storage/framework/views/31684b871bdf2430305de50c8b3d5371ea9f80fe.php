<?php $__env->startPush('meta'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('stylesheet'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/home.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/payement.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('Body_Page'); ?>
    <section>
        <div id="Titre">
            <h3>Paiement</h3>
            <!-- <a href="<?php echo e(route('cart.alldestroy')); ?>"><span>Annuller mon payement</span></a> -->
        </div>

        <div id="Message">
            <div class="alert alert-danger" role="alert" id="Alert">
                
            </div>
        </div>

        <div id="Article" class="col-xs-12">
            <form action="<?php echo e(route('payement.store')); ?>" method="post" id="Payement_form">
                <?php echo csrf_field(); ?>

                <div class="Part col-xs-12 col-xs-12">
                    <div class="input_label">
                        <label for="Carte"><span class="fa fa-credit-card" id="Label"></span></label>
                        <input type="text" name="carte_credit" id="Carte" placeholder="Numéro de carte">
                    </div>

                    <div class="inputs">
                        <input type="text" name="date" placeholder="MM / AA">
                        <input type="text" name="cvc" placeholder="CVC">
                    </div>
                </div>

                <div class="Part col-xs-12 col-xs-12">
                    <button type="submit">
                        <span id="Submit">Procéder au paiement</span>
                    </button>
                </div>
            </form>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('script'); ?>
    <script type="module" src="<?php echo e(asset('js/ajax.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts/master', ['titre' => 'Payement'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\cours\Laravel\Project to use\E-commerce\resources\views/pages/payement.blade.php ENDPATH**/ ?>