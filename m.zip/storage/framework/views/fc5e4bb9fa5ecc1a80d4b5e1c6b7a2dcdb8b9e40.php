


<?php $__env->startPush('stylesheet'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/home.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/panier.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/historique.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('Body_Page'); ?>
    <section>
        <div id="Titre">
            <h3>Historique</h3>
        </div>
        <div id="Message">
            <?php if(session('success')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>
        </div>
            
        <?php if($historiques->count() == 0): ?>
            <div id="Vide" class="col-xs-12">
                <h3>Votre Historique est vide</h3>
            </div>
        <?php else: ?>
        	<?php $__currentLoopData = $historiques; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $historique): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div id="Article" class="col-xs-12">
                    <div class="Titre">
                        <div class="part">
                            <span>Commande passée le </span>
                            <span><?php echo e(getMyDate($historique->payment_create_at)); ?></span>
                        </div>
                        <div class="part">
                            <span><?php echo e(getPrice($historique->amount)); ?></span>
                        </div>
                    </div>
                    
                    <div class="Orders">
                        <?php $__currentLoopData = unserialize($historique->products); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="body">
                                <div class="photo" style="background-image: url(<?php echo e(asset($article[2])); ?>);"></div>

                                <div class="valeur">
                                    <span><?php echo e($article[0]); ?></span>
                                    <span>Prix : <?php echo e(getPrice($article[1])); ?></span>
                                    <span>Quantité : <?php echo e($article[3]); ?></span>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php echo e($historiques->appends(request()->input())->links()); ?>

        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts/master', ['titre' => 'Historique'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/samy/Projets/Samy/E-commerce/resources/views/pages/historique.blade.php ENDPATH**/ ?>