<?php $__env->startPush('stylesheet'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/home.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('Body_Page'); ?>
    <section>
    	<div id="News">
    		<h3><?php echo e($categorie->name); ?></h3>

    		
    		<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    		<div class="Product col-xs-6 col-sm-4 col-md-3 col-lg-2">
	    			<article>
	    				<div class="options">
    						<?php if(auth()->guard()->guest()): ?>
	    						<a href="#" id="Favori_plus" title="Ajouter au favori">
	    							<span class="fa fa-heart-o"></span>
	    							
				                    <form action="<?php echo e(route('favori.store')); ?>" method="post" style="display: none;" id="Form_Favori">
				                        <?php echo csrf_field(); ?>
				                        <input type="hidden" name="favori_id" value="<?php echo e($categorie->id); ?>">
				                    </form>
	    						</a>
	    					<?php else: ?>
	    						<a href="#" id="Favori_plus" title="Ajouter au favori">
	    							<span class="<?php echo e(getLike($categorie->id)); ?>"></span>
	    							
				                    <form action="<?php echo e(route('favori.store')); ?>" method="post" style="display: none;" id="Form_Favori">
				                        <?php echo csrf_field(); ?>
				                        <input type="hidden" name="favori_id" value="<?php echo e($categorie->id); ?>">
				                    </form>
	    						</a>
    						<?php endif; ?>

    						<a href="#" id="Cart_plus" title="Ajouter au panier">
    							<span class="fa fa-cart-plus"></span>
    							
			                    <form action="<?php echo e(route('cart.store')); ?>" method="post" style="display: none;" id="Form_hidden">
			                        <?php echo csrf_field(); ?>
			                        <input type="hidden" name="product_id" value="<?php echo e($categorie->id); ?>">
			                    </form>
    						</a>
	    				</div>

	    				<div class="image_article">
	    					<div class="int" style="background-image: url(<?php echo e($categorie->image); ?>);"></div>
	    				</div>

	    				<div class="describe">
	    					<span><?php echo e($categorie->titre); ?></span>
	    					<span><?php echo e($categorie->getPrice()); ?></span>
	    				</div>

	    				<div class="show">
	    					<a href="<?php echo e(route('product.index', $categorie->slug)); ?>">Voir plus</a>
	    				</div>
	    			</article>

    				<?php echo e($categories->appends(request()->input())->links()); ?>

	    		</div>
    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    	</div>
    </section>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('js/home.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts/master', ['titre' => 'Categorie'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\cours\Laravel\Project to use\E-commerce\resources\views/pages/categorie.blade.php ENDPATH**/ ?>