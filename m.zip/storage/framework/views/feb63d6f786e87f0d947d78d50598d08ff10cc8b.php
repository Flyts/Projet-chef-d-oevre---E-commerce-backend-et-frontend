
    <?php echo $__env->make('layouts/partials/_head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



	<!-- include('layouts/partials/_loader') -->




	<?php echo $__env->make('layouts/partials/_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



    <?php echo $__env->yieldContent('Body_Page'); ?>



	<?php echo $__env->make('layouts/partials/_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



	<?php echo $__env->make('layouts/partials/_foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH E:\cours\Laravel\Project to use\E-commerce\resources\views/layouts/master.blade.php ENDPATH**/ ?>