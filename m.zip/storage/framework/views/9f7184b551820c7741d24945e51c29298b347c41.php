<?php $__env->startPush('stylesheet'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/home.css')); ?>">

    <?php if(getSousCategoryExist($categorie->id) > 0): ?>
    	<link rel="stylesheet" href="<?php echo e(asset('css/categorys.css')); ?>">
	    <link rel="stylesheet" href="<?php echo e(asset('css/owl/owl.carousel.min.css')); ?>">
	    <link rel="stylesheet" href="<?php echo e(asset('css/owl/owl.theme.default.min.css')); ?>">
    <?php endif; ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('Body_Page'); ?>
    <section class="sam">

	    <?php if(getSousCategoryExist($categorie->id) > 0): ?>
	    	<div id="Nav_category" style="background-color: <?php if($slug === 'hommes'): ?> var(--bluegrey) <?php elseif($slug === 'femmes'): ?> #ec407a <?php endif; ?>;">
				<ul>
		    		<?php $__currentLoopData = getSousCategory($categorie->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $SousCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li id="li">
							<span><?php echo e($SousCategory->name); ?></span>

							<div class="Affiche">
								<div class="par_produit">
									<h5>Voir Par Produit</h5>

									<div class="contents">	
										<nav>
											<?php $__currentLoopData = getOtherSousCategory_1($SousCategory->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $OtherSousCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<a href="<?php echo e(route('othercategory', [$categorie->slug, $OtherSousCategory->slug])); ?>"><?php echo e($OtherSousCategory->name); ?></a>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</nav>
										<nav>
											<?php $__currentLoopData = getOtherSousCategory_2($SousCategory->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $OtherSousCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<a href="<?php echo e(route('othercategory', [$categorie->slug, $OtherSousCategory->slug])); ?>"><?php echo e($OtherSousCategory->name); ?></a>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</nav>
									</div>
								</div>

								<div class="my_images">
									<div class="contents">	
		    							<?php $__currentLoopData = getImages($categorie->id, $SousCategory->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $SousCategoryImage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		    								<a href="<?php echo e(route('product.index', $SousCategoryImage->slug)); ?>">
		    									<div class="imgs">
		    										<div class="int" style="background-image: url(<?php echo e(asset($SousCategoryImage->image)); ?>);"></div>
		    									</div>
		    								</a>
		    							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</div>
								</div>
							</div>
						</li>
		    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
	    	</div>
	    <?php endif; ?>

    	<div id="Banner">
    		<div class="Image" style="<?php echo e(getImageBanner($slug)); ?>">
    			<?php if($slug === 'hommes' || $slug === 'femmes'): ?>
    				<h4 style="text-align: center;">vêtements Pour <?php echo e($slug); ?> en solde</h4>
    			<?php endif; ?>
		    	<div class="owl-carousel owl-theme">
	    			<?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="Part">
							<div class="imgs" style="background-image: url(<?php echo e(asset($banner->image)); ?>);"></div>
							<a href="<?php echo e(route('product.index', $banner->slug)); ?>" class="titre" style="color: var(--bluegrey_f); text-decoration: none;">
								<span><?php echo e($banner->titre); ?></span>
							</a>
						</div>
	    			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    			</div>
    		</div>
    	</div>

    	<div id="Presentation">
    		<div class="First">
    			<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    			<div class="part col-xs-12 col-sm-6 col-md-4 col-lg-3">
	    				<a href="<?php echo e(route('product.index', $categorie->slug)); ?>" class="img">	
	    					<div class="int" style="background-image: url(<?php echo e(asset($categorie->image)); ?>);">
	    					</div>
	    					
    						<div class="text">
    							<span><?php echo e($categorie->titre); ?></span>
		    					<span>
		    						<?php if($categorie->solde != null): ?>
		    							<i><?php echo e(getPrice($categorie->price)); ?></i>
		    							<strong><?php echo e(getMySolde($categorie->price, $categorie->solde)); ?></strong>
		    						<?php else: ?>
		    							<?php echo e(getPrice($categorie->price)); ?>

		    							<strong style="visibility: hidden;"><?php echo e(getMySolde($categorie->price, $categorie->solde)); ?></strong>
		    						<?php endif; ?>
		    					</span>
    						</div>
	    				</a>
	    			</div>
    			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    		</div>
    	</div>
    </section>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('js/home.js')); ?>"></script>
    <script src="<?php echo e(asset('js/down.js')); ?>"></script>
    <script src="<?php echo e(asset('js/owl/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/owl-modif.js')); ?>"></script>
    <script src="<?php echo e(asset('js/secondaire_menu.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts/master', ['titre' => 'Categorie '.$nom_categorie], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Cours\Laravel\Project to use\E-commerce\resources\views/pages/categorie.blade.php ENDPATH**/ ?>