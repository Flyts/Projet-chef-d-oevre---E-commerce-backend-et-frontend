<?php $__env->startPush('meta'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('stylesheet'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/home.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/panier.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/favori.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('Body_Page'); ?>
    <section>
        <div id="Titre" style="margin-bottom: 40px;">
            <h3>favoris</h3>

            <?php if($favoris->count() != 0): ?>
                <div class="Seach">
                    <form action="<?php echo e(route('favori.navigation')); ?>" method="POST" id="Form">
                        <?php echo csrf_field(); ?>

                        <label for="Input">
                            <i class="fa fa-search"></i>
                        </label>
                        <input type="text" name="navigation" id="Input">
                    </form>
                </div>

                <a href="<?php echo e(route('favori.alldestroy', $all)); ?>"><span>Effacer tous vos favoris</span></a>
            <?php endif; ?>
        </div>
            
        <?php if($favoris->count() == 0): ?>
            <div id="Vide" class="col-xs-12">
                <h3>Vous n'avez pas de favori</h3>
            </div>
        <?php else: ?>
            <div id="Content">
                <div class="Utilities">
                    <?php echo csrf_field(); ?>
                </div>

                <?php $__currentLoopData = $favoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $favori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div id="Article" class="col-xs-12">
                        <div class="Content">
                            <div class="aside">
                                <div class="photo" style="background-image: url(<?php echo e(asset($favori->image)); ?>);"></div>
                                <div class="text">
                                    <span><?php echo e($favori->titre); ?></span>
                                    <span class="subtitle"><?php echo e($favori->subtitle); ?></span>
                                    <div class="voir">
                                        <a href="<?php echo e(route('product.index', $favori->slug)); ?>" class="a">Voir plus</a>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="Other">
                            <span class="price"><?php echo e(getPrice($favori->price)); ?></span>

                            <a href="#" id="Cart_plus" class="Cart_plus_favori" title="Ajouter au panier">
                                <span class="fa fa-cart-plus"></span>
                                
                                <form action="<?php echo e(route('cart.store')); ?>" method="post" style="display: none;" id="Form_hidden">
                                    <?php echo csrf_field(); ?>

                                    <input type="hidden" name="product_id" value="<?php echo e($favori->id); ?>">
                                </form>
                            </a>

                            <form action="<?php echo e(route('favori.destroy', $favori->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                
                                <button type="submit"  title="Supprimer de vos favoris">
                                    <span class="fa fa-times-circle"></span>
                                </button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div>
                <?php echo e($favoris->appends(request()->input())->links()); ?>

            </div>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('script'); ?>
    <script type="module" src="<?php echo e(asset('js/panier.js')); ?>"></script>
    <script src="<?php echo e(asset('js/home.js')); ?>"></script>
    <script src="<?php echo e(asset('js/favori_search.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts/master', ['titre' => 'Favori'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Projets\Samy\E-commerce\resources\views/pages/favori.blade.php ENDPATH**/ ?>