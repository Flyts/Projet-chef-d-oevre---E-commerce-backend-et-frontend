<?php $__env->startPush('meta'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('stylesheet'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/home.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/panier.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('Body_Page'); ?>
    <section>
        <div id="Titre">
            <h3>Panier</h3>
            <a href="<?php echo e(route('cart.alldestroy')); ?>"><span>Vider mon panier</span></a>
        </div>
        <div id="Message">
            <?php if(session('success')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>
        </div>
            
        <?php if($paniers->count() == 0): ?>
            <div id="Vide" class="col-xs-12">
                <h3>Votre panier est vide</h3>
            </div>
        <?php else: ?>
        	<?php $__currentLoopData = $paniers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $panier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div id="Article" class="col-xs-12">
                    <div class="Content">
                        <div class="quantity">
                            <div class="add">
                                <!-- <span class="fa fa-plus"></span> -->
                                <input type="number" name="qty" data-id="<?php echo e($panier->rowId); ?>" id="Qty" value="<?php echo e($panier->qty); ?>" min="1">
                            </div>
                        </div>
                        <div class="aside">
                            <div class="photo" style="background-image: url(<?php echo e(asset($panier->model->image)); ?>);"></div>
                            <div class="text">
                                <span><?php echo e($panier->model->titre); ?></span>
                                <span><?php echo e($panier->model->subtitle); ?></span>
                                <div class="stock">
                                    <span class="fa fa-check"></span>En stock
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="Other">
                        <span><?php echo e(getPrice($panier->subtotal())); ?></span>
                        <form action="<?php echo e(route('cart.destroy', ['rowId' => $panier->rowId, 'qty' => $panier->qty])); ?>" method="post">
                            <?php echo csrf_field(); ?>

                            <button type="submit">
                                <span class="fa fa-times-circle"></span>
                            </button>
                        </form>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div id="Total" class="col-xs-12">
                <div class="Coupon_code col-xs-12 col-md-6">
                    <h4>Coupon Code</h4>
                    <div class="int">
                        <form action="#" method="post">
                            <input type="text" name="code" placeholder="Appliquer le coupon">

                            <button type="submit">
                                <span class="fa fa-gift"></span>Appliquer
                            </button>
                        </form>
                    </div>
                </div>

                <div class="Recapitulatif col-xs-12 col-md-6">
                    <h4>Récapitulatif</h4>
                    <div class="int">
                        <div class="part">
                            <div class="one">
                                <span>Panier</span>
                                <span><?php echo e(getProductPlural(Cart::count())); ?></span>
                            </div>
                            <div class="two">
                                <span><?php echo e(getPriceNotTaxe(Cart::subtotal())); ?></span>
                            </div>
                        </div>

                        <div class="part">
                            <div class="one">
                                <span>Frais de livraison</span>
                                <span>Livraison à kinshasa</span>
                            </div>
                            <div class="two">
                                <span>0 $</span>
                            </div>
                        </div>

                        <div class="part">
                            <div class="one">
                                <span>Taxe</span>
                                <span></span>
                            </div>
                            <div class="two">
                                <span><?php echo e(getMyTaxe(Cart::total())); ?></span>
                            </div>
                        </div>

                        <hr>

                        <div class="total_price">
                            <span>Total</span>
                            <span><?php echo e(getPrice(Cart::total())); ?></span>
                        </div>

                        <div class="Validate">
                            <a href="<?php echo e(route('payement.index')); ?>">
                                <span>Passer à la caisse</span>
                            </a>
                        </div>
                    </div>

                </div>
            </div>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('script'); ?>
    <script type="module" src="<?php echo e(asset('js/panier.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts/master', ['titre' => 'Panier'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Cours\Laravel\Project to use\E-commerce\resources\views/pages/panier.blade.php ENDPATH**/ ?>