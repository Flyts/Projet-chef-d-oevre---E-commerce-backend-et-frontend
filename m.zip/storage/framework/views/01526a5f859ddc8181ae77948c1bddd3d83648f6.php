<?php $__env->startPush('meta'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('stylesheet'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/home.css')); ?>">

    <?php if(getSousCategoryExist($categorie->id) > 0): ?>
    	<link rel="stylesheet" href="<?php echo e(asset('css/categorys.css')); ?>">
    	<link rel="stylesheet" href="<?php echo e(asset('css/othersouscategorys.css')); ?>">
    <?php endif; ?>

    <link rel="stylesheet" href="<?php echo e(asset('css/partials/_AjaxLoader.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('Body_Page'); ?>
    <section>

	    <?php if(getOtherSousCategoryExist($souscategorie->id) > 0): ?>
            <div id="Nav_category" style="background-color: <?php if($slug === 'hommes'): ?> var(--bluegrey) <?php elseif($slug === 'femmes'): ?> #ec407a <?php endif; ?>;">
				<ul>
		    		<?php $__currentLoopData = getSousCategory($categorie->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $SousCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li>
							<span><?php echo e($SousCategory->name); ?></span>

							<div class="Affiche">
								<div class="par_produit">
									<h5>Voir Par Produit</h5>

									<div class="contents">	
										<nav>
											<?php $__currentLoopData = getOtherSousCategory_1($SousCategory->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $OtherSousCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<a href="<?php echo e(route('othercategory', [$categorie->slug, $OtherSousCategory->slug])); ?>"><?php echo e($OtherSousCategory->name); ?></a>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</nav>
										<nav>
											<?php $__currentLoopData = getOtherSousCategory_2($SousCategory->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $OtherSousCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<a href="<?php echo e(route('othercategory', [$categorie->slug, $OtherSousCategory->slug])); ?>"><?php echo e($OtherSousCategory->name); ?></a>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</nav>
									</div>
								</div>

								<div class="my_images">
									<div class="contents">	
		    							<?php $__currentLoopData = getImages($categorie->id, $SousCategory->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $SousCategoryImage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		    								<a href="<?php echo e(route('product.index', $SousCategoryImage->slug)); ?>">
		    									<div class="imgs">
		    										<div class="int" style="background-image: url(<?php echo e(asset($SousCategoryImage->image)); ?>);"></div>
		    									</div>
		    								</a>
		    							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</div>
								</div>
							</div>
						</li>
		    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
	    	</div>
	    <?php endif; ?>

    	<div id="News">
    		<h3>
    			<?php echo e($souscategorie->name. ' - ' .$othersouscategorie->name); ?> 
    			<span style="text-transform: lowercase;"><?php echo e(' pour ' .$categorie->name); ?></span>
    		</h3>

    		<div class="Trier">
    			<form action="<?php echo e(route('othercategory.store')); ?>" id="Form" method="POST">
    				<div class="input">
    					<div class="trier content" id="0">
    						<input type="hidden" name="slug" value="<?php echo e($slug); ?>">
    						<input type="hidden" name="otherSlug" value="<?php echo e($otherSlug); ?>">
    						<input type="number" name="combien" value="<?php echo e(getNombreArticleAfficher()); ?>" style="display: none;" id="combien">

    						<span>Trier <i class="fa fa-angle-down"></i></span>
    						<div class="navs">
    							<li id="nouveau">
    								Nouveau
    								<strong><i></i></strong>
    							</li>
    							<li id="dcroissant">
    								Prix décroissant
    								<strong><i></i></strong>
    							</li>
    							<li id="croissant">
    								Prix croissant
    								<strong><i></i></strong>
    							</li>
    						</div>

    						<input type="hidden" name="trier" value="0" id="input">
    					</div>


    					<div class="marque content" id="0">
    						<span>Marque <i class="fa fa-angle-down"></i></span>
    						<div class="navs">
    							<li id="0">
    								Tout
    								<strong><i></i></strong>
    							</li>

                                <?php $__currentLoopData = $marques; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marque): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(getMarqueExist($marque->id, $otherSlug) > 0): ?>
                                        <li id="<?php echo e($marque->id); ?>">
                                            <?php echo e($marque->name); ?>

                                            <strong><i></i></strong>
                                        </li>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    						</div>

    						<input type="hidden" name="marque" value="0" id="input">
    					</div>


    					<div class="couleur content" id="0">
    						<span>Couleur <i class="fa fa-angle-down"></i></span>
    						<div class="navs">
    							<li id="0">
    								Tout
    								<strong><i></i></strong>
    							</li>
                                
                                <?php $__currentLoopData = $couleurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $couleur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(getCouleurExist($couleur->id, $otherSlug) > 0): ?>
                                        <li id="<?php echo e($couleur->id); ?>">
                                            <?php echo e($couleur->name); ?>

                                            <strong><i></i></strong>
                                        </li>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    						</div>

    						<input type="hidden" name="couleur" value="0" id="input">
    					</div>


    					<div class="taille content" id="0">
    						<span>Taille <i class="fa fa-angle-down"></i></span>
    						<div class="navs">
    							<li id="0">
    								Tout
    								<strong><i></i></strong>
    							</li>
                                
                                <?php $__currentLoopData = $tailles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $taille): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(getTailleExist($taille->id, $otherSlug) > 0): ?>
                                        <li id="<?php echo e($taille->id); ?>">
                                            <?php echo e($taille->name); ?>

                                            <strong><i></i></strong>
                                        </li>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    						</div>

    						<input type="hidden" name="taille" value="0" id="input">
    					</div>


    					<!-- <div class="content" id="0">
    						<span>Gamme de prix <i class="fa fa-angle-down"></i></span>
    						<div class="navs">
    							<li>
    								Tout
    								<strong><i></i></strong>
    							</li>
    							<li>
    								Nouveau
    								<strong><i></i></strong>
    							</li>
    						</div>
    					</div> -->
    				</div>

    				<div class="Utilities">
    					<span class="route_favori"   id="<?php echo e(route('favori.store')); ?>"></span>
    					<span class="route_addCart"  id="<?php echo e(route('cart.store')); ?>"></span>
    					<span class="route_viewMore" id="<?php echo e(route('product.index', $categorie->slug)); ?>"></span>
    					<?php echo csrf_field(); ?>
    				</div>
    			</form>

    			<div id="Close_Trie"></div>
    		</div>

            <div class="Value_Trie">
                <div class="part">
                    <span>Trier par : </span>
                    <span class="trier_choisi">Aucun</span>
                </div>

                <div class="part">
                    <span>Marque : </span>
                    <span class="marque_choisi">Tout</span>
                </div>

                <div class="part">
                    <span>Couleur : </span>
                    <span class="couleur_choisi">Tout</span>
                </div>

                <div class="part">
                    <span>Taille : </span>
                    <span class="taille_choisi">Tout</span>
                </div>
            </div>

    		
    		<?php $__currentLoopData = $othersouscategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    		<div class="Product col-xs-6 col-sm-4 col-md-3 col-lg-2">
	    			<article>
	    				<div class="options">
    						<?php if(auth()->guard()->guest()): ?>
	    						<div class="icons" id="Favori_plus" title="Ajouter au favori">
	    							<span class="fa fa-heart-o"></span>
	    							
				                    <form action="<?php echo e(route('favori.store')); ?>" method="post" style="display: none;" id="Form_Favori">
				                        <?php echo csrf_field(); ?>
				                        <input type="hidden" name="favori_id" value="<?php echo e($categorie->id); ?>">
				                    </form>
	    						</div>
	    					<?php else: ?>
	    						<div class="icons" id="Favori_plus" title="Ajouter au favori">
	    							<span class="<?php echo e(getLike($categorie->id)); ?>"></span>
	    							
				                    <form action="<?php echo e(route('favori.store')); ?>" method="post" style="display: none;" id="Form_Favori">
				                        <?php echo csrf_field(); ?>
				                        <input type="hidden" name="favori_id" value="<?php echo e($categorie->id); ?>">
				                    </form>
	    						</div>
    						<?php endif; ?>

    						<div class="icons" id="Cart_plus" title="Ajouter au panier">
    							<span class="fa fa-cart-plus"></span>
    							
			                    <form action="<?php echo e(route('cart.store')); ?>" method="post" style="display: none;" id="Form_hidden">
			                        <?php echo csrf_field(); ?>
			                        <input type="hidden" name="product_id" value="<?php echo e($categorie->id); ?>">
			                    </form>
    						</div>
	    				</div>

	    				<div class="image_article">
	    					<div class="int" style="background-image: url(<?php echo e(asset($categorie->image)); ?>);"></div>
	    				</div>

	    				<div class="describe">
	    					<span><?php echo e($categorie->titre); ?></span>
                            <span>
                                <?php if($categorie->solde != null): ?>
                                    <i><?php echo e(getPrice($categorie->price)); ?></i>
                                    <strong><?php echo e(getMySolde($categorie->price, $categorie->solde)); ?></strong>
                                <?php else: ?>
                                    <?php echo e(getPrice($categorie->price)); ?>

                                    <strong style="visibility: hidden;"><?php echo e(getMySolde($categorie->price, $categorie->solde)); ?></strong>
                                <?php endif; ?>
                            </span>
	    				</div>

	    				<div class="show">
	    					<a href="<?php echo e(route('product.index', $categorie->slug)); ?>">Voir plus</a>
	    				</div>
	    			</article>
	    		</div>
    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    	</div>

    	<div id="Hide_results">
    		<form style="display: none;">
    			<input type="number" name="combien" value="<?php echo e(getNombreArticleAfficher()); ?>">
    		</form>

            <div class="Result_count">
                <span>Vous avez vu</span>
                <span class="nombre_deja_vu"><?php echo e(getNombreDejaVu($counts)); ?></span>
                <span>articles sur</span>
                <span class="nombre_a_voir"><?php echo e($counts); ?></span>
            </div>

            <div class="Chargement">
                <div class="int" style="width: <?php echo e(getPourcentage(getNombreDejaVu($counts), $counts)); ?>;"></div>
            </div>

            <?php if($counts === getNombreDejaVu($counts)): ?>
                <button id="afficher_plus" style="display: none;">
                    <span>Afficher Plus</span>
                </button>
            <?php else: ?>
                <button id="afficher_plus">
                    <span>Afficher Plus</span>
                </button>
            <?php endif; ?>
    	</div>


    	<?php echo $__env->make('layouts/partials/_AjaxLoader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </section>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('js/othersouscategory/TrieAjax.js')); ?>"></script>
    <script src="<?php echo e(asset('js/othersouscategory/plusderesultats.js')); ?>"></script>
    <script src="<?php echo e(asset('js/secondaire_menu.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts/master', ['titre' => $nom_categorie. ' '. $othersouscategorie->name], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Cours\Laravel\Project to use\E-commerce\resources\views/pages/souscategorie.blade.php ENDPATH**/ ?>