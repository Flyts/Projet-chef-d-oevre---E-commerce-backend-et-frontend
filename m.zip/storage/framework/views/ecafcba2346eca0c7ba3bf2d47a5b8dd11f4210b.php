<?php $__env->startPush('meta'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('stylesheet'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/home.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/edit_user.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('Body_Page'); ?>
    <section>
        <div id="Titre">
            <h3>Modifier mon compte</h3>
        </div>
            
        <div id="Article" class="col-xs-12">
          <div id="Corps">
            <div class="container-fluid">
              <div class="row">
                <div class="Block col-xs-12 col-sm-12 col-md12">
                  <form action="<?php echo e(route('edit.update')); ?>" method="POST" class="block_photo" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    
                    <div class="change_photo">
                      <div class="photo" style="background-image: url(<?php echo e(asset(Auth::user()->avatar)); ?>);">
                        
                      </div>

                      <div class="button">  
                        <div class="file">
                          <input type="file" name="avatar"  hidden="hidden" id="real_file" required>

                          <button type="button" id="custom_file">
                            <?php echo app('translator')->get('modifier.btn_file'); ?>
                          </button>

                          <span id="custom_text">Aucune photo Choisi</span>
                        </div>
                        
                        <?php $__errorArgs = ['avatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="error"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                        <button type="submit" style="margin-top: 20px;">
                          <span>
                            <?php echo app('translator')->get('modifier.btn_enregistrer'); ?>
                          </span>
                        </button>
                      </div>
                    </div>
                  </form>

                  <form action="<?php echo e(route('edit.modifier')); ?>" method="POST" class="block_int">
                    <?php echo csrf_field(); ?>

                    <div class="change_info">
                      <div class="general_info">
                        <h3><?php echo app('translator')->get('modifier.info_General'); ?></h3>
                        <div class="label_input_1 label_input">

                          <div class="int">
                            <label for="Nom"><?php echo app('translator')->get('modifier.nom'); ?></label>
                            <input type="text" name="nom" id="Nom" placeholder="<?php echo app('translator')->get('modifier.placeholder_Nom'); ?>" value="<?php echo e($errors->first('nom') ? old('nom') : Auth::user()->nom); ?>" class="<?php $__errorArgs = ['nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> errors <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>

                            <?php $__errorArgs = ['nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="error"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </div>

                          <div class="int">
                            <label for="Prénom"><?php echo app('translator')->get('modifier.prenom'); ?></label>
                            <input type="text" name="prenom" id="Prénom" placeholder="<?php echo app('translator')->get('modifier.placeholder_Prenom'); ?>" value="<?php echo e($errors->first('prenom') ? old('prenom') : Auth::user()->prenom); ?>" class="<?php $__errorArgs = ['prenom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> errors <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>

                            <?php $__errorArgs = ['prenom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="error"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </div>
                        </div>
                      </div>

                      <div class="info_compte">
                        <h3><?php echo app('translator')->get('modifier.info_Compte'); ?></h3>
                        <div class="label_input"> 

                          <div class="int">
                            <label for="TEL"><?php echo app('translator')->get('modifier.tel'); ?></label>
                            <input type="text" name="tel" id="TEL" placeholder="<?php echo app('translator')->get('modifier.placeholder_tel'); ?>" value="<?php echo e($errors->first('tel') ? old('tel') : Auth::user()->tel); ?>" class="<?php $__errorArgs = ['tel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> errors <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>

                            <?php $__errorArgs = ['tel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="error"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </div>

                          <div class="int">
                            <label for="id"><?php echo app('translator')->get('modifier.identifiant'); ?></label>
                            <input type="text" name="identifiant" id="id" placeholder="<?php echo app('translator')->get('modifier.placeholder_id'); ?>" value="<?php echo e($errors->first('identifiant') ? old('identifiant') : Auth::user()->identifiant); ?>" class="<?php $__errorArgs = ['identifiant'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> errors <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>

                            <?php $__errorArgs = ['identifiant'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="error"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </div>
                        </div>
                      </div>

                      <div class="change_pass">
                        <h3><?php echo app('translator')->get('modifier.change_passe'); ?></h3>

                        <div class="label_input">
                          <div class="int">
                            <label for="actuel_pass"><?php echo app('translator')->get('modifier.pass_actuel'); ?></label>
                            <input type="password" name="ancien_pass" id="actuel_pass" placeholder="<?php echo app('translator')->get('modifier.placeholder_pass'); ?>" required>

                            <?php if(session('passeword_error')): ?>
                                <div class="error">
                                    <?php echo e(session('passeword_error')); ?>

                                </div>
                            <?php endif; ?>
                          </div>

                          <div class="int">
                            <label for="change_pass"><?php echo app('translator')->get('modifier.pass_new'); ?></label>
                            <input type="password" name="password" id="change_pass" placeholder="<?php echo app('translator')->get('modifier.placeholder_pass'); ?>" class="<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> errors <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>

                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="error"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </div>

                          <div class="int">
                            <label style="visibility: hidden;">confirmation</label>
                            <input type="password" name="password_confirmation" id="confirm_pass" placeholder="<?php echo app('translator')->get('modifier.confirm_pass'); ?>" required>
                          </div>
                      </div>
                    </div>

                    <div class="Save_btn">
                      <button type="submit">
                        <span><?php echo app('translator')->get('modifier.btn_enregistrer'); ?></span>
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('script'); ?>
    <script type="module" src="<?php echo e(asset('js/custom_file_btn.js')); ?>"></script>
<?php $__env->stopPush(); ?>





        
<?php echo $__env->make('layouts/master', ['titre' => 'Modifier compte'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Cours\Laravel\Project to use\E-commerce\resources\views/pages/edit_user.blade.php ENDPATH**/ ?>