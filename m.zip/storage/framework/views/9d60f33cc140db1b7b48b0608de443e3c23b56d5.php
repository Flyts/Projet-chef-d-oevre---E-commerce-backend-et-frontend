<?php $__env->startPush('stylesheet'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/home.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/panier.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/contact.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('Body_Page'); ?>
    <section>
        <div id="Titre">
            <h3>Contactez Nous</h3>
        </div>

        <div id="Article" class="col-xs-12">
            <div class="Info">
                <div class="part">
                    <div class="int">
                        <div class="icon">
                            <i class="fa fa-map-marker"></i>
                        </div>
                        <div class="text">
                            <span>Localisation :</span>
                            <span><?php echo e(getInfo('location')); ?></span>
                        </div>
                    </div>
                </div>
                <div class="part">
                    <div class="int">
                        <div class="icon">
                            <i class="fa fa-phone"></i>
                        </div>
                        <div class="text">
                            <span>Phone :</span>
                            <span><?php echo e(getInfo('phone')); ?></span>
                        </div>
                    </div>
                    <div class="int">
                        <div class="icon">
                            <i class="fa fa-envelope"></i>
                        </div>
                        <div class="text">
                            <span>Mail :</span>
                            <span><?php echo e(getInfo('email')); ?></span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="Send_mail">
                <form action="<?php echo e(route('contact')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    
                    <?php if($errors->isNotEmpty()): ?>
                        <div class="alert alert-danger" role="alert">
                            <ul>
                                <?php if($errors->first('nom') != '' ): ?><li><?php echo e($errors->first('nom')); ?></li><?php endif; ?>
                                <?php if($errors->first('email') != '' ): ?><li><?php echo e($errors->first('email')); ?></li><?php endif; ?>
                                <?php if($errors->first('sujet') != '' ): ?><li><?php echo e($errors->first('sujet')); ?></li><?php endif; ?>
                                <?php if($errors->first('message') != '' ): ?><li><?php echo e($errors->first('message')); ?></li><?php endif; ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <div class="deux">
                        <div class="label_input">
                            <input type="text" name="nom" id="Nom" autocomplete="off" value="<?php echo e(old('nom')); ?>" class="<?php $__errorArgs = ['nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> errors <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                            <label for="Nom" class="label_name">
                                <span class="content_name">Votre Nom</span>
                            </label>
                        </div>  

                        <div class="label_input">
                            <input type="email" name="email" id="Mail" autocomplete="off" value="<?php echo e(old('email')); ?>" class="<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> errors <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                            <label for="Mail" class="label_name">
                                <span class="content_name">Votre Mail</span>
                            </label>
                        </div> 
                    </div>
                    <div class="un">
                        <div class="label_input">
                            <input type="text" name="sujet" id="Sujet" autocomplete="off" value="<?php echo e(old('sujet')); ?>" class="<?php $__errorArgs = ['sujet'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> errors <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                            <label for="Sujet" class="label_name">
                                <span class="content_name">Votre Sujet</span>
                            </label>
                        </div>  

                        
                        <textarea  name="message" placeholder="Votre Message"  value="<?php echo e(old('message')); ?>" class="<?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> errors <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required></textarea>


                        <button type="submit">
                            <span>Envoyer</span>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts/master', ['titre' => 'Contact'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Cours\Laravel\Project to use\E-commerce\resources\views/pages/contact.blade.php ENDPATH**/ ?>