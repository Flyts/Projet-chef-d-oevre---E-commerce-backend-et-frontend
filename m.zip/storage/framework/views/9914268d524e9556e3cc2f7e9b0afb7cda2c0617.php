
<nav>
	<ul>
		<?php $__currentLoopData = App\Models\Categorys::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li>
				<a href="<?php echo e(route('categorie.index', $category->slug)); ?>" id="<?php echo e($category->slug); ?>">
					<span class="fa fa-<?php echo e($category->icon); ?>"></span><?php echo e($category->name); ?>

				</a>
			</li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</ul>
</nav>
<?php /**PATH /home/samy/Projets/Samy/E-commerce/resources/views/layouts/partials/_nav-menu.blade.php ENDPATH**/ ?>