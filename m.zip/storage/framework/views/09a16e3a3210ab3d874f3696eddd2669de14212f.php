<?php $__env->startPush('meta'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('stylesheet'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/home.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/owl/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/owl/owl.theme.default.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('Body_Page'); ?>
    <section>
    	<div id="News">
    		<div class="Titre">
    			<h3>Nouveaux Produits</h3>
    			<div class="btns">
    				<span class="fa fa-chevron-left" id="Chevron_left"></span>
    				<span class="fa fa-chevron-right" id="Chevron_right"></span>
    			</div>
    		</div>

		    <?php if($products->count() > 0): ?>
		    	<div class="owl-carousel owl-theme">
		    		<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			    		<div class="Product">
			    			<article>
			    				<div class="options">
		    						<?php if(auth()->guard()->guest()): ?>
		    							<a href="#" id="Favori_plus" title="Ajouter au favori">
			    							<span class="fa fa-heart-o"></span>
			    							
						                    <form action="<?php echo e(route('favori.store')); ?>" method="post" style="display: none;" id="Form_Favori">
						                        <?php echo csrf_field(); ?>
						                        <input type="hidden" name="favori_id" value="<?php echo e($product->id); ?>">
						                    </form>
			    						</a>
		    						<?php else: ?>
		    							<a href="#" id="Favori_plus" title="Ajouter au favori">
			    							<span class="<?php echo e(getLike($product->id)); ?>"></span>
			    							
						                    <form action="<?php echo e(route('favori.store')); ?>" method="post" style="display: none;" id="Form_Favori">
						                        <?php echo csrf_field(); ?>
						                        <input type="hidden" name="favori_id" value="<?php echo e($product->id); ?>">
						                    </form>
			    						</a>
		    						<?php endif; ?>

		    						<a href="#" id="Cart_plus" title="Ajouter au panier">
		    							<span class="fa fa-cart-plus"></span>
		    							
					                    <form action="<?php echo e(route('cart.store')); ?>" method="post" style="display: none;" id="Form_hidden">
					                        <?php echo csrf_field(); ?>
					                        <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
					                    </form>
		    						</a>
			    				</div>

			    				<div class="image_article">
			    					<div class="int" style="background-image: url(<?php echo e(asset($product->image)); ?>);"></div>
			    				</div>

			    				<div class="describe">
			    					<span><?php echo e($product->titre); ?></span>
			    					<span>
			    						<?php if($product->solde != null): ?>
			    							<i><?php echo e(getPrice($product->price)); ?></i>
			    							<strong><?php echo e(getMySolde($product->price, $product->solde)); ?></strong>
			    						<?php else: ?>
			    							<?php echo e(getPrice($product->price)); ?>

			    							<strong style="visibility: hidden;"><?php echo e(getMySolde($product->price, $product->solde)); ?></strong>
			    						<?php endif; ?>
			    					</span>
			    				</div>

			    				<div class="show">
			    					<a href="<?php echo e(route('product.index', $product->slug)); ?>">Voir plus</a>
			    				</div>
			    			</article>
			    		</div>
		    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		    	</div>
		    <?php endif; ?>
    	</div>



		<?php if($plusvendu->count() > 0): ?>
    		<div id="News">
	    		<h3>Produits Le Plus Vendu</h3>

	    		<?php $__currentLoopData = $plusvendu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		    		<div class="Product col-xs-6 col-sm-4 col-md-3 col-lg-2">
		    			<article>
		    				<div class="options">
	    						<?php if(auth()->guard()->guest()): ?>
	    							<a href="#" id="Favori_plus" title="Ajouter au favori">
		    							<span class="fa fa-heart-o"></span>
		    							
					                    <form action="<?php echo e(route('favori.store')); ?>" method="post" style="display: none;" id="Form_Favori">
					                        <?php echo csrf_field(); ?>
					                        <input type="hidden" name="favori_id" value="<?php echo e($vente->produt_id); ?>">
					                    </form>
		    						</a>
	    						<?php else: ?>
	    							<a href="#" id="Favori_plus" title="Ajouter au favori">
		    							<span class="<?php echo e(getLike($vente->produt_id)); ?>"></span>
		    							
					                    <form action="<?php echo e(route('favori.store')); ?>" method="post" style="display: none;" id="Form_Favori">
					                        <?php echo csrf_field(); ?>
					                        <input type="hidden" name="favori_id" value="<?php echo e($vente->produt_id); ?>">
					                    </form>
		    						</a>
	    						<?php endif; ?>

	    						<a href="#" id="Cart_plus" title="Ajouter au panier">
	    							<span class="fa fa-cart-plus"></span>
	    							
				                    <form action="<?php echo e(route('cart.store')); ?>" method="post" style="display: none;" id="Form_hidden">
				                        <?php echo csrf_field(); ?>
				                        <input type="hidden" name="product_id" value="<?php echo e($vente->produt_id); ?>">
				                    </form>
	    						</a>
		    				</div>

		    				<div class="image_article">
		    					<div class="int" style="background-image: url(<?php echo e(asset($vente->image)); ?>);"></div>
		    				</div>

		    				<div class="describe">
		    					<span><?php echo e($vente->name_produt); ?></span>
		    					<span>
		    						<?php echo e(getPrice($vente->price)); ?>

		    					</span>
		    				</div>

		    				<div class="show">
		    					<a href="<?php echo e(route('product.index', $vente->slug)); ?>">Voir plus</a>
		    				</div>
		    			</article>
		    		</div>
	    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	    	</div>
		<?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('js/home.js')); ?>"></script>
    <script src="<?php echo e(asset('js/owl/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/owl-modif.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts/master', ['titre' => 'Home'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Projets\Samy\E-commerce\resources\views/pages/home.blade.php ENDPATH**/ ?>