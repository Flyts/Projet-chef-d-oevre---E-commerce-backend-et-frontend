<?php $__env->startPush('stylesheet'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/home.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/search.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('Body_Page'); ?>
    <section>
    	<div id="News">
    		<h3>Recherche</h3>

    		<h5><span><?php echo e(getResultat($counts->where('stock', '>', 0)->count())); ?></span> pour la recherche "<strong><?php echo e(request()->input('search')); ?></strong>".</h5>

    		<?php if($products->total() > 0): ?>
    			<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		    		<?php if($product->stock > 0): ?>
			    		<div class="Product col-xs-12 col-sm-4 col-md-3 col-lg-2">
			    			<article>
			    				<div class="options">
		    						<?php if(auth()->guard()->guest()): ?>
		    							<a href="#" id="Favori_plus" title="Ajouter au favori">
			    							<span class="fa fa-heart-o"></span>
			    							
						                    <form action="<?php echo e(route('favori.store')); ?>" method="post" style="display: none;" id="Form_Favori">
						                        <?php echo csrf_field(); ?>
						                        <input type="hidden" name="favori_id" value="<?php echo e($product->id); ?>">
						                    </form>
			    						</a>
		    						<?php else: ?>
		    							<a href="#" id="Favori_plus" title="Ajouter au favori">
			    							<span class="<?php echo e(getLike($product->id)); ?>"></span>
			    							
						                    <form action="<?php echo e(route('favori.store')); ?>" method="post" style="display: none;" id="Form_Favori">
						                        <?php echo csrf_field(); ?>
						                        <input type="hidden" name="favori_id" value="<?php echo e($product->id); ?>">
						                    </form>
			    						</a>
		    						<?php endif; ?>

		    						<a href="#" id="Cart_plus">
		    							<span class="fa fa-cart-plus"></span>
		    							
					                    <form action="<?php echo e(route('cart.store')); ?>" method="post" style="display: none;" id="Form_hidden">
					                        <?php echo csrf_field(); ?>
					                        <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
					                    </form>
		    						</a>
			    				</div>

			    				<div class="image_article">
			    					<div class="int" style="background-image: url(<?php echo e(asset($product->image)); ?>);"></div>
			    				</div>

			    				<div class="describe">
			    					<span><?php echo e($product->titre); ?></span>
			    					<span>
			    						<?php if($product->solde != null): ?>
			    							<i><?php echo e(getPrice($product->price)); ?></i>
			    							<strong><?php echo e(getMySolde($product->price, $product->solde)); ?></strong>
			    						<?php else: ?>
			    							<?php echo e(getPrice($product->price)); ?>

			    							<strong style="visibility: hidden;"><?php echo e(getMySolde($product->price, $product->solde)); ?></strong>
			    						<?php endif; ?>
			    					</span>
			    				</div>

			    				<div class="show">
			    					<a href="<?php echo e(route('product.index', $product->slug)); ?>">Show</a>
			    				</div>
			    			</article>
			    		</div>
		    		<?php endif; ?>
	    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    		<?php else: ?>
    			<div class="Product col-xs-12">
	    			<article style="display: flex; justify-content: center; align-items: center; box-shadow: none; padding: 20px;">
	    				<div class="in" style="background-image: url(<?php echo e(asset('img/Nada.png')); ?>); background-size: contain; height: 250px; width: 250px;">
	    					
	    				</div>
	    			</article>
	    		</div>
    		<?php endif; ?>
    	</div>

		<div id="Pagination">
			<?php echo e($products->appends(request()->input())->links()); ?>

		</div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('js/home.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts/master', ['titre' => 'Recherche'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Cours\Laravel\Project to use\E-commerce\resources\views/pages/search.blade.php ENDPATH**/ ?>