
  
    <footer>
		FIN
    </footer>
  
<?php /**PATH E:\cours\Laravel\Project to use\E-commerce\resources\views/layouts/partials/_footer.blade.php ENDPATH**/ ?>