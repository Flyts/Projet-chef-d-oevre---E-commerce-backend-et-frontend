<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    
    <meta name="description" content="description du site pour google">

    <?php echo $__env->yieldPushContent('meta'); ?>

    
    <link rel="stylesheet" href="<?php echo e(asset('css/fram/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/fram/font-awesome/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/fram/flyts.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css//fram/swiper.min.css')); ?>">


    <link rel="stylesheet" href="<?php echo e(asset('css//modif/swiper_modif.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/partials/_header.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/partials/_footer.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/partials/_avatar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/partials/_categories.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/partials/_nav-menu.css')); ?>">
    
    <?php echo $__env->yieldPushContent('stylesheet'); ?>

    
    <link rel="shorcut icon" href="<?php echo e(asset('img/logo.png')); ?>">
    <title><?php echo e(config('app.name')); ?> - <?php echo e($titre); ?></title>
  </head>
  <body><?php /**PATH E:\Projets\Samy\E-commerce\resources\views/layouts/partials/_head.blade.php ENDPATH**/ ?>