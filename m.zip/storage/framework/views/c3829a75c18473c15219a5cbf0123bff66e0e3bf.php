<?php $__env->startPush('meta'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('stylesheet'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/home.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('Body_Page'); ?>
    <section>
    	<?php if(auth()->guard()->guest()): ?>
    	<?php else: ?>
    		<?php if($FavoriteSearchs != []): ?>
	    		<div id="News">
		    		<h3>Recherche favorite</h3>

		    		<?php $__currentLoopData = $FavoriteSearchs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $FavoriteSearch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			    		<div class="Product col-xs-6 col-sm-4 col-md-3 col-lg-2">
			    			<article>
			    				<div class="options">
		    						<?php if(auth()->guard()->guest()): ?>
		    							<a href="#" id="Favori_plus" title="Ajouter au favori">
			    							<span class="fa fa-heart-o"></span>
			    							
						                    <form action="<?php echo e(route('favori.store')); ?>" method="post" style="display: none;" id="Form_Favori">
						                        <?php echo csrf_field(); ?>
						                        <input type="hidden" name="favori_id" value="<?php echo e($FavoriteSearch->id); ?>">
						                    </form>
			    						</a>
		    						<?php else: ?>
		    							<a href="#" id="Favori_plus" title="Ajouter au favori">
			    							<span class="<?php echo e(getLike($FavoriteSearch->id)); ?>"></span>
			    							
						                    <form action="<?php echo e(route('favori.store')); ?>" method="post" style="display: none;" id="Form_Favori">
						                        <?php echo csrf_field(); ?>
						                        <input type="hidden" name="favori_id" value="<?php echo e($FavoriteSearch->id); ?>">
						                    </form>
			    						</a>
		    						<?php endif; ?>

		    						<a href="#" id="Cart_plus" title="Ajouter au panier">
		    							<span class="fa fa-cart-plus"></span>
		    							
					                    <form action="<?php echo e(route('cart.store')); ?>" method="post" style="display: none;" id="Form_hidden">
					                        <?php echo csrf_field(); ?>
					                        <input type="hidden" name="product_id" value="<?php echo e($FavoriteSearch->id); ?>">
					                    </form>
		    						</a>
			    				</div>

			    				<div class="image_article">
			    					<div class="int" style="background-image: url(<?php echo e($FavoriteSearch->image); ?>);"></div>
			    				</div>

			    				<div class="describe">
			    					<span><?php echo e($FavoriteSearch->titre); ?></span>
			    					<span><?php echo e($FavoriteSearch->getPrice()); ?></span>
			    				</div>

			    				<div class="show">
			    					<a href="<?php echo e(route('product.index', $FavoriteSearch->slug)); ?>">Voir plus</a>
			    				</div>
			    			</article>
			    		</div>
		    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		    	</div>
    		<?php endif; ?>
    	<?php endif; ?>

    	

    	<div id="News">
    		<h3>Nouveaux Produits</h3>

    		<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    		<div class="Product col-xs-6 col-sm-4 col-md-3 col-lg-2">
	    			<article>
	    				<div class="options">
    						<?php if(auth()->guard()->guest()): ?>
    							<a href="#" id="Favori_plus" title="Ajouter au favori">
	    							<span class="fa fa-heart-o"></span>
	    							
				                    <form action="<?php echo e(route('favori.store')); ?>" method="post" style="display: none;" id="Form_Favori">
				                        <?php echo csrf_field(); ?>
				                        <input type="hidden" name="favori_id" value="<?php echo e($product->id); ?>">
				                    </form>
	    						</a>
    						<?php else: ?>
    							<a href="#" id="Favori_plus" title="Ajouter au favori">
	    							<span class="<?php echo e(getLike($product->id)); ?>"></span>
	    							
				                    <form action="<?php echo e(route('favori.store')); ?>" method="post" style="display: none;" id="Form_Favori">
				                        <?php echo csrf_field(); ?>
				                        <input type="hidden" name="favori_id" value="<?php echo e($product->id); ?>">
				                    </form>
	    						</a>
    						<?php endif; ?>

    						<a href="#" id="Cart_plus" title="Ajouter au panier">
    							<span class="fa fa-cart-plus"></span>
    							
			                    <form action="<?php echo e(route('cart.store')); ?>" method="post" style="display: none;" id="Form_hidden">
			                        <?php echo csrf_field(); ?>
			                        <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
			                    </form>
    						</a>
	    				</div>

	    				<div class="image_article">
	    					<div class="int" style="background-image: url(<?php echo e($product->image); ?>);"></div>
	    				</div>

	    				<div class="describe">
	    					<span><?php echo e($product->titre); ?></span>
	    					<span><?php echo e($product->getPrice()); ?></span>
	    				</div>

	    				<div class="show">
	    					<a href="<?php echo e(route('product.index', $product->slug)); ?>">Voir plus</a>
	    				</div>
	    			</article>
	    		</div>
    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    	</div>

		<div id="Pagination">
			<?php echo e($products->appends(request()->input())->links()); ?>

		</div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('js/home.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts/master', ['titre' => 'Home'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\cours\Laravel\Project to use\E-commerce\resources\views/pages/home.blade.php ENDPATH**/ ?>