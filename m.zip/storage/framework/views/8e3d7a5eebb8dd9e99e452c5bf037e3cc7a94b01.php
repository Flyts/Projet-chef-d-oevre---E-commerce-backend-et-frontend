<?php $__env->startPush('stylesheet'); ?>
    <link rel="stylesheet" href="css/home.css">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('Body_Page'); ?>
    <section>
    	<div id="News">
    		<h3>Newest Products</h3>

    		<div class="Product col-lg-12">
    			<article>
    				<div class="options">
						<a href="#"><span class="fa fa-heart-o"></span></a>

						<a href="#"><span class="fa fa-cart-plus"></span></a>
    				</div>

    				<div class="image_article">
    					<div class="int" style="background-image: url(<?php echo e($product->image); ?>);"></div>
    				</div>

    				<div class="describe">
    					<span><?php echo e($product->title); ?></span>
    					<span><?php echo e($product->getPrice()); ?></span>
    				</div>
    			</article>
    		</div>
    	</div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/master', ['titre' => 'Boutique'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\cours\Laravel\Project to use\E-commerce\resources\views/boutique.blade.php ENDPATH**/ ?>