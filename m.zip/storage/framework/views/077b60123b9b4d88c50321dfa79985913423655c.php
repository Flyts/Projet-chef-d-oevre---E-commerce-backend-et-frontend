
  
    <footer>
		<div id="Wenze" class="col-xs-12 col-sm-12 col-md-4">
			<div class="Titre">
				<span><?php echo e(config('app.name')); ?></span>
			</div>

			<div class="Content">
				<div class="part">
                    <i class="fa fa-map-marker"></i> <?php echo e(getInfo('location')); ?>

				</div>
				<div class="part">
                    <i class="fa fa-phone"></i> <?php echo e(getInfo('phone')); ?>

				</div>
				<div class="part">
                    <i class="fa fa-envelope"></i> <?php echo e(getInfo('email')); ?>

				</div>
				<div class="social">
                    <a href="<?php echo e(getInfoLien('facebook')); ?>" _bank><i class="fa fa-facebook"></i></a>
                    <a href="<?php echo e(getInfoLien('twitter')); ?>"><i class="fa fa-twitter"></i></a>
				</div>
			</div>
		</div>

		<div id="Categories"  class="col-xs-12 col-sm-6 col-md-4">
			<div class="Titre">
				<span>Categories</span>
			</div>

			<div class="Content">
				<ul>
					<?php $__currentLoopData = getCategories(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li><a href="<?php echo e(route('categorie.index', $item->slug)); ?>"><?php echo e($item->name); ?></a></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
		</div>

		<div id="Infomation"  class="col-xs-12 col-sm-6 col-md-4">
			<div class="Titre">
				<span>Infomation</span>
			</div>

			<div class="Content">
				<ul>
					<li>
						<a href="<?php echo e(route('a-propos-de-nous')); ?>" class="<?php echo e(active_page('a-propos-de-nous')); ?>">A Propos de Nous</a>
					</li>
					<li>
						<a href="<?php echo e(route('contact')); ?>" class="<?php echo e(active_page('contact')); ?>">Contactez Nous</a>
					</li>
					<li>
						<a href="#">Termes & Conditions</a>
					</li>
					<li>
						<a href="#">Retours & Echanges</a>
					</li>
				</ul>
			</div>
		</div>

		<div id="Last"  class="col-xs-12">
			<div class="Copyright">
				© 2020 <a href="#">FlyTs</a> All Right Reserved.
			</div>

			<div class="Menu">
				<ul>
					<?php $__currentLoopData = getMenus(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li><a href="<?php echo e(route($item->lien)); ?>" class="<?php echo e(active_page($item->lien)); ?>"><?php echo e($item->name); ?></a></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
		</div>



		<div id="BackTop">
			<span class="fa fa-chevron-up"></span>
		</div>
    </footer>
  
<?php /**PATH E:\Projets\Samy\E-commerce\resources\views/layouts/partials/_footer.blade.php ENDPATH**/ ?>