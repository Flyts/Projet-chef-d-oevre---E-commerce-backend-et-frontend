
  
    <header>
		<div id="Nav">
			<div class="Logo_Menu">	
				<a href="<?php echo e(route('home')); ?>"><div class="logo"></div></a>

				<div class="menu">
					<ul>
					
						<?php $__currentLoopData = App\Models\menus::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li><a href="<?php echo e(route($menu->lien)); ?>" class="<?php echo e(active_page($menu->lien)); ?>"><?php echo e($menu->name); ?></a></li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</ul>

					<div class="Bars">
						<button id="Bars">
							<span class="fa fa-bars"></span>
						</button>
					</div>
				</div>
			</div>

			<div class="Options">
				
				<button id="Active_Secondaire">
					<span class="fa fa-ellipsis-v"></span>
				</button>

				<a href="<?php echo e(route('cart.index')); ?>" class="<?php echo e(active_page('cart.index')); ?>">
					<span class="fa fa-shopping-bag"></span>
					<sup class="Badge badge badge-pill badge-dark"><?php echo e(Cart::count()); ?></sup>
				</a>
				<button id="Active_search">
					<span class="fa fa-search"></span>
				</button>

				<?php if(auth()->guard()->guest()): ?>
					<a href="" title="Connection & Enregistrement" id="Active_Connexion" style="font-size: 20px;">
						<span class="fa fa-user"></span>
					</a>

					<div class="connexion_user" id="Connexion_user">
						<a href="<?php echo e(route('login')); ?>">
							<span class="fa fa-sign-in"></span>Connection
						</a>
						<a href="<?php echo e(route('register')); ?>">
							<span class="fa fa-sign-out"></span>Enregistrement
						</a>
					</div>
				<?php else: ?>
					<div class="Photo" style="background-image: url(<?php echo e(asset(Auth::user()->avatar)); ?>);" id="Avatar_btn">
					</div>

					<div id="Avatar">
						<div class="Name">
							<span><?php echo e(Auth::user()->nom); ?></span>
							<span><?php echo e(Auth::user()->prenom); ?></span>
						</div>
						<ul class="ul">
							<div class="part">
								<li>
									<a href="<?php echo e(route('edit.index')); ?>" class="<?php echo e(active_page('edit.index')); ?>">
										<div><span class="fa fa-edit"></span>Modifier mon compte</div>
									</a>
								</li>
								<li>
									<a href="<?php echo e(route('historique')); ?>" class="<?php echo e(active_page('historique')); ?>">
										<div><span class="fa fa-history"></span>Historique</div>
										<strong class="avatar_Badge badge badge-pill badge-dark"><?php echo e(getHistory()); ?></strong>
									</a>
								</li>
								<li>
									<a href="<?php echo e(route('favori.index')); ?>" class="<?php echo e(active_page('favori.index')); ?>">
										<div><span class="fa fa-heart"></span>Favori</div>
										<strong class="avatar_Badge badge badge-pill badge-dark"><?php echo e(getFovor()); ?></strong>
									</a>
								</li>
								<li>
									<a href="<?php echo e(route('banque')); ?>" class="<?php echo e(active_page('banque')); ?>">
										<div><span class="fa fa-money"></span>Wenze Money</div>
										<strong class="avatar_Badge badge badge-pill badge-dark"><?php echo e(getPriceSansTaxe(getSolde())); ?></strong>
									</a>
								</li>
							</div>
							<div class="other">	
								<li>
									<a href="<?php echo e(route('logout')); ?>"
					                    onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
										<div><span class="fa fa-sign-out"></span>Déconnexion</div>
									</a>

					                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
					                    <?php echo csrf_field(); ?>
					                </form>
								</li>
							</div>
						</ul>
					</div>
				<?php endif; ?>
			</div>
		</div>

		<div id="Welcome">
			<article class="col-xs-12 col-md-5 col-lg-4">
				<div class="Categories">
					<div class="titre">
						<span>Categories</span>
					</div>


					<?php echo $__env->make('layouts/partials/_nav-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



				</div>
				
				<div class="Btns">
					<?php if(auth()->guard()->guest()): ?>
						<a href="<?php echo e(route('register')); ?>">
							<span>Créer compte</span>
						</a>

						<a href="<?php echo e(route('login')); ?>">
							<span>Connexion</span>
						</a>
					<?php else: ?>
						<a href="<?php echo e(route('logout')); ?>"
                            onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
							<span>Déconnexion</span>
						</a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
					<?php endif; ?>
				</div>
			</article>

			<aside class="col-xs-12 col-md-7 col-lg-8">
				<div class="image">
					<?php if(!empty($product)): ?>
						<div class="int" style="background-image: url(<?php echo e($product->image); ?>);" id="Image"></div>
					<?php elseif(!empty($sam)): ?>
						<div class="int" style="background-image: url(<?php echo e($sam->image); ?>);"></div>
					<?php else: ?>
					<?php endif; ?>
				</div>
			</aside>
		</div>

		<div id="Down">
			<button>
				<span class="fa fa-chevron-down"></span>
			</button>
		</div>
    </header>

						
	<div id="Black"></div>

	<div id="Search_bar">
		<form action="<?php echo e(route('product.search')); ?>" method="get">
			<button type="button" id="Close_search">
				<span class="fa fa-close"></span>
			</button>

			<div class="Part">
				<input type="text" name="search" placeholder="Recherche..." required autofocus>
				<select name="categorie" id="">
					<option value="0" selected>Tout</option>
					<?php $__currentLoopData = App\Models\Categorys::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($categorie->id); ?>"><?php echo e($categorie->name); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</div>

			<button type="submit">
				<span class="fa fa-search"></span>
			</button>
		</form>
	</div>

	<div id="Search_black"></div>
	<div id="Avatar_black"></div>
  


<?php /**PATH E:\Cours\Laravel\Project to use\E-commerce\resources\views/layouts/partials/_header.blade.php ENDPATH**/ ?>