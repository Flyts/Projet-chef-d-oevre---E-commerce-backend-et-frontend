    <!-- Jquery --> 
    <script src="<?php echo e(asset('js/fram/jquery-1.12.4-min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/fram/jquery-ui-min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/fram/jquery.min.js')); ?>"></script>

    <!-- BOOTSTRAP JavaScript -->
    <script src="<?php echo e(asset('js/fram/bootstrap.min.js')); ?>"></script>

    <!-- SWIPER JavaScript -->
    <script src="<?php echo e(asset('js/fram/swiper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/fram/popper.min.js')); ?>"></script>

    <!-- Mon JavaScript & jquery -->
    <script src="<?php echo e(asset('js/modif/swiper_modif.js')); ?>"></script>
    <script src="<?php echo e(asset('js/main.js')); ?>"></script>
    <script src="<?php echo e(asset('js/search.js')); ?>"></script>
    <script src="<?php echo e(asset('js/avatar.js')); ?>"></script>
    <script src="<?php echo e(asset('js/connexion_user.js')); ?>"></script>
    <script src="<?php echo e(asset('js/backtop.js')); ?>"></script>

    <?php echo $__env->yieldPushContent('script'); ?>

    <?php echo $__env->make('flashy::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
  </body>
</html><?php /**PATH E:\Cours\Laravel\Project to use\E-commerce\resources\views/layouts/partials/_foot.blade.php ENDPATH**/ ?>