<?php $__env->startPush('stylesheet'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/home.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/boutique.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('Body_Page'); ?>
    <section>
    	<div id="Article">
            <div class="All_photo col-xs-12 col-md-2">
                <?php if(empty($product->other_images)): ?>
                    <div class="photo" id="photo">
                        <div class="int" style="background-image: url(<?php echo e(asset($product->image)); ?>);"></div>
                    </div>
                <?php else: ?>
                    <?php $__currentLoopData = unserialize($product->other_images); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $other): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="photo" id="photo">
                            <div class="int" style="background-image: url(<?php echo e(asset($product->image)); ?>);" id="Other"></div>
                        </div>
                        <div class="photo">
                            <div class="int" style="background-image: url(<?php echo e(asset($other[0])); ?>);"   id="Other"></div>
                        </div>
                        <div class="photo">
                            <div class="int" style="background-image: url(<?php echo e(asset($other[1])); ?>);"   id="Other"></div>
                        </div>
                        <div class="photo">
                            <div class="int" style="background-image: url(<?php echo e(asset($other[2])); ?>);"   id="Other"></div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>

            <div class="Photo col-xs-12 col-md-4">
                <div class="int" style="background-image: url(<?php echo e(asset($product->image)); ?>);"  id="Photo_change"></div>
            </div>

            <div class="Content col-xs-12 col-lg-6">
                <div class="title">
                    <span><?php echo e($product->titre); ?></span>
                    <?php if(auth()->guard()->guest()): ?>
                        <span class="fa fa-heart-o" id="Favori_plus" title="Ajouter au favori">
                            <form action="<?php echo e(route('favori.store')); ?>" method="post" style="display: none;" id="Form_Favori">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="favori_id" value="<?php echo e($product->id); ?>">
                            </form>
                        </span>
                    <?php else: ?>
                        <span class="<?php echo e(getLike($product->id)); ?>" id="Favori_plus" title="Ajouter au favori">
                            <form action="<?php echo e(route('favori.store')); ?>" method="post" style="display: none;" id="Form_Favori">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="favori_id" value="<?php echo e($product->id); ?>">
                            </form>
                        </span>
                    <?php endif; ?>
                </div>

                <div class="subtitle">
                    <span><?php echo e($product->subtitle); ?></span>
                </div>

                <div class="price">
                    <span>
                        <?php if($product->solde != null): ?>
                            <i><?php echo e(getPrice($product->price)); ?></i>
                            <strong><?php echo e(getMySolde($product->price, $product->solde)); ?></strong>
                        <?php else: ?>
                            <?php echo e(getPrice($product->price)); ?>

                        <?php endif; ?>
                    </span>
                </div>

                <div class="color">
                    <?php if($product->couleur_id != null): ?>
                        <span>Couleur :</span>
                        <span><?php echo e(getCouleur($product->couleur_id)); ?></span>
                    <?php endif; ?>
                </div>

                <div class="color">
                    <?php if($product->taille_id != null): ?>
                        <span>Taille :</span>
                        <span><?php echo e(getTaille($product->taille_id)); ?></span>
                    <?php endif; ?>
                </div>


                <?php if($product->stock <= 5): ?>
                    <div class="stock">
                            <i class="fa fa-clock-o"></i> 
                            <span>bientôt épuisé</span>
                    </div>
                <?php endif; ?>

                <div class="quantity">
                    <form action="<?php echo e(route('cart.store')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        
                        <div class="label_input">
                            <label for="Quantity">Quantité</label>
                            <input type="number" name="size" min="1" id="Quantity" placeholder="Enter votre quantité" class="<?php $__errorArgs = ['size'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('errors'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(1 ?? old('size')); ?>" required>

                            <?php $__errorArgs = ['size'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="error"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                        <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">

                        <button type="submit">
                            <span>Ajouter au panier</span>
                        </button>
                    </form>
                </div>

                <div class="describe"><!-- 
                    <div class="titre">Description</div>
                    <span><?php echo e($product->description); ?></span>
                
                 -->
                    <div>
                        <ul class="tabs">
                            <li class="active">
                                <div id="titre" class="home">Description</div>
                            </li>
                            <li>
                                <div id="titre" class="mentions">Mentions</div>
                            </li>
                            <li>
                                <div id="titre" class="about">About</div>
                            </li>
                        </ul>
                        <div class="tabs-content">
                            <div class="tab-content active" id="home">
                                <?php echo e($product->description); ?>

                            </div>

                            <div class="tab-content" id="mentions"> 
                                consectetur adipisicing elit. Fuga, ullam, similique. Provident magnam deserunt error at nostrum impedit ipsa obcaecati, enim, quis sed, sequi ab dolorem reprehenderit beatae optio neque!
                            </div>

                            <div class="tab-content" id="about">
                                sit amet, consectetur adipisicing elit. Rem magni doloribus non nisi unde consectetur deleniti provident earum sed, iste autem voluptatibus eligendi soluta porro nemo incidunt! Voluptatibus, provident, est!
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    	</div>
    </section>
<?php $__env->stopSection(); ?>



<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('js/home.js')); ?>"></script>
    <script src="<?php echo e(asset('js/boutique.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts/master', ['titre' => 'Boutique'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Projets\Samy\E-commerce\resources\views/pages/boutique.blade.php ENDPATH**/ ?>