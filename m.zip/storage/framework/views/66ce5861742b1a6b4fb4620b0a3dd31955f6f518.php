

<?php $__env->startPush('meta'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('stylesheet'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/home.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/merci.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('Body_Page'); ?>
    <section>
        <div id="Titre">
            <?php if(session('success')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
        </div>

        <div id="Article" class="col-xs-12">
            <h1>Merci</h1>
            <h4>Vous allez être rédirigé vers la page d'accueil dans <span id="second"></span></h4>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('script'); ?>
    <script>
        
        /*Redirect*/

        (function()
        {
            setInterval(function()
            {
                window.location.href = '';
            }, 5000);
        })();

        (function()
        {
            var second = document.querySelector('#second');
            var i = 5;

            second.innerHTML = i;

            var times = setInterval(function()
            {
                i--;
                second.innerHTML = i;

                if (i == 0) 
                {
                    clearInterval(times);      
                }
            }, 1000);
        })();
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts/master', ['titre' => 'Payement'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/samy/Projets/Samy/E-commerce/resources/views/pages/merci.blade.php ENDPATH**/ ?>